package threadcount.nugget;

import java.util.ArrayList;

public class WeatherItem {
    public String date;
    public double max;
    public double min;
    public String cond;

    public WeatherItem(String date, double max, double min, String cond) {
        this.date = date;
        this.max = max;
        this.min = min;
        this.cond = cond;
    }

    public static ArrayList<WeatherItem> listData(){
        ArrayList<WeatherItem> items = new ArrayList<>();
        items.add(new WeatherItem("Tomorrow", 25.0d, 19.0d, "Windy"));
        items.add(new WeatherItem("Jumbo", 25.0d, 19.0d, "Windy"));
        return items;
    }
}
