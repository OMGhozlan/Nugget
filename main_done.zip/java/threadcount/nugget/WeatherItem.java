package threadcount.nugget;

import android.content.Context;
import android.util.Log;

import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import static java.lang.Math.max;

public class WeatherItem {
    public int id;
    public String date;
    public double max;
    public double min;
    public String cond;

    public WeatherItem(int id, String date, double max, double min, String cond) {
        this.id = id;
        this.date = date;
        this.max = max;
        this.min = min;
        this.cond = cond;
    }

    public int getID(){
        return this.id;
    }

    public void setID(long id){
        this.id = (int)id;
    }

    public static ArrayList<WeatherItem> listData(WeatherDataSource wDS, Context context) {
        ArrayList<WeatherItem> items = new ArrayList<>();
        /*items.add(new WeatherItem(0, "Tomorrow", 25.0d, 19.0d, "Windy"));
        items.add(new WeatherItem(1, "Jumbo", 25.0d, 19.0d, "Windy"));*/
        long curr_time = new Date().getTime();
        if (!(curr_time < LoginSharedPreference.getUpdate(context))){
            Calendar c = Calendar.getInstance();
            c.setTime(new Date());
            String[] days = {
                    "", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
            };
            final JSONObject[] json = {null};
            new Thread() {
                public void run() {
                    json[0] = WeatherData.getJSON(null, "Cairo,EG");
                }
            }.start();
            while (json[0] == null) {
            }
            /*JSONObject json = WeatherData.getJSON(null, "Cairo,EG");*/
            for (int i = 0; i < 7; i++) {
                try {
                    /*details.getString("description").toUpperCase(Locale.US) +
                                "\n" + "Humidity: " + main.getString("humidity") + "%" +
                                "\n" + "Pressure: " + main.getString("pressure") + " hPa");
                    * */
                    JSONObject details = json[0].getJSONArray("list").getJSONObject(i).getJSONArray("weather").getJSONObject(0);
                    JSONObject main = json[0].getJSONArray("list").getJSONObject(i);
                    items.add(wDS.createWeatherItem(i, days[max(1, (c.get(Calendar.DAY_OF_WEEK) + i) % days.length)],
                            main.getJSONObject("temp").getDouble("max"),
                            main.getJSONObject("temp").getDouble("min"),
                            details.getString("description").toUpperCase(Locale.US)));
                    /*items.add(new WeatherItem(i, days[max(1, (c.get(Calendar.DAY_OF_WEEK) + i) % days.length)],
                            main.getJSONObject("temp").getDouble("max"),
                            main.getJSONObject("temp").getDouble("min"),
                            details.getString("description").toUpperCase(Locale.US)));*/
                    Log.i("Nugget>Weather", "Data retrieval successful");
                } catch (Exception e) {
                    Log.e("Nugget>Weather", "One or more fields missing in JSON data");
                }
            }
        }else{
            try{
                items = wDS.getAllWeatherItems();
                Log.i("Nugget>Weather", "DB fetching successful");
            }catch (Exception e) {
                Log.e("Nugget>Weather", "DB fetching problem");
            }
        }
        return items;
    }
}
