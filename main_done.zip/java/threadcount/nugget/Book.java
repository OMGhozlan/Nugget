package threadcount.nugget;

import java.util.ArrayList;

public class Book {
    ArrayList<String> cat;
    String id, name, author, series_t, genre_s;
    boolean inStock;
    int sequence_i, pages_i;
    double price;
}
