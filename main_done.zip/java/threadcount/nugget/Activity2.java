package threadcount.nugget;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Activity2 extends AppCompatActivity {

    final WeatherDataSource datasource = new WeatherDataSource(this);
    ListView listView;
    WeatherItemAdapter WeatherAdapter;
    /*final WeatherDBHelper wDB = new WeatherDBHelper(this);*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        /*makeList();*/
        datasource.open();
        makeWeatherList();
    }

    @Override
    protected void onResume() {
        super.onResume();
        datasource.open();
    }

    @Override
    protected void onStop() {
        super.onStop();
        datasource.close();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.activity_2_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.update_info){
            LoginSharedPreference.setUpdate(Activity2.this, -1l);
            this.WeatherAdapter = new WeatherItemAdapter(this, WeatherItem.listData(datasource, Activity2.this));
            this.WeatherAdapter.notifyDataSetChanged();
            Toast.makeText(getApplicationContext(), "Update successful!", Toast.LENGTH_SHORT).show();
        }
        return false;
    }

    public void logout(View view){
        SharedPreferences sharedpref = getSharedPreferences(Activity1.login_data, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedpref.edit();
        editor.clear();
        editor.commit();
    }

    private void makeList(){
        Toast.makeText(getApplicationContext(), "Listing items..", Toast.LENGTH_SHORT).show();
        ArrayList<Item> items = new ArrayList<Item>();
        ItemAdapter adapter = new ItemAdapter(this, Item.listItems());
        ListView listView = (ListView) findViewById(R.id.list_items);
        listView.setAdapter(adapter);
    }

    private void makeWeatherList(){
        Toast.makeText(getApplicationContext(), "Listing days..", Toast.LENGTH_SHORT).show();
        ArrayList<WeatherItem> items = new ArrayList<>();
        /*wDB.addWeatherEntry(99, "Never", 10.0d, 10.0d, "Kek");
        datasource.createWeatherItem(99, "Never", 10.0d, 10.0d, "Kek");
        WeatherItemAdapter adapter = new WeatherItemAdapter(this, wDB.getAllWeatherItems(wDB));
        WeatherItemAdapter adapter = new WeatherItemAdapter(this, datasource.getAllWeatherItems());*/
        /*WeatherItemAdapter adapter = new WeatherItemAdapter(this, WeatherItem.listData(datasource, Activity2.this));
        ListView listView = (ListView) findViewById(R.id.list_items);*/
        this.WeatherAdapter = new WeatherItemAdapter(this, WeatherItem.listData(datasource, Activity2.this));
        this.listView = findViewById(R.id.list_items);
        this.listView.setAdapter(this.WeatherAdapter);
        this.listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(), Integer.toString(position), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Activity2.this, WeatherActivity.class);
                startActivity(intent);
            }
        });
        this.WeatherAdapter.notifyDataSetChanged();
    }
}
