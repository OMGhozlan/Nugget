package threadcount.nugget;

import android.content.Context;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class WeatherFragment extends Fragment {
    Typeface weatherFont;

    TextView cityField;
    TextView updatedField;
    TextView detailsField;
    TextView currentTemperatureField;
    TextView weatherIcon;

    Handler handler;

    /*private void drawIcon(int actualId, long sunrise, long sunset) {*/
    private void drawIcon(int actualId) {
        int id = actualId / 100;
        String icon = "";
        if (actualId == 800) {
            /*long currentTime = new Date().getTime();*/
            int currentTime = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
            if (currentTime >= 7 && currentTime < 17) {
                icon = getActivity().getString(R.string.weather_sunny);
            } else {
                icon = getActivity().getString(R.string.weather_clear_night);
            }
        } else {
            switch (id) {
                case 2:
                    icon = getActivity().getString(R.string.weather_thunder);
                    break;
                case 3:
                    icon = getActivity().getString(R.string.weather_drizzle);
                    break;
                case 7:
                    icon = getActivity().getString(R.string.weather_foggy);
                    break;
                case 8:
                    icon = getActivity().getString(R.string.weather_cloudy);
                    break;
                case 6:
                    icon = getActivity().getString(R.string.weather_snowy);
                    break;
                case 5:
                    icon = getActivity().getString(R.string.weather_rainy);
                    break;
            }
        }
        weatherIcon.setText(icon);
    }

    private void displayWeather(JSONObject json) {
        try {
            cityField.setText(json.getJSONObject("city").getString("name").toUpperCase(Locale.US) +
                    ", " +
                    json.getJSONObject("city").getString("country"));

            JSONObject details = json.getJSONArray("list").getJSONObject(0).getJSONArray("weather").getJSONObject(0);
            JSONObject main = json.getJSONArray("list").getJSONObject(0);
            detailsField.setText(
                    details.getString("description").toUpperCase(Locale.US) +
                            "\nHumidity: " + main.getString("humidity") + "%" +
                            "\nPressure: " + main.getString("pressure") + " hPa\n"
                            + "Min: " + main.getJSONObject("temp").getDouble("min") + " ℃\nMax: "
                            + main.getJSONObject("temp").getDouble("max") + " ℃");
            /*currentTemperatureField.setText(
                    String.format("Min: %.2f℃\nMax: %.2f℃\n",
                            main.getJSONObject("temp").getDouble("min"),
                            main.getJSONObject("temp").getDouble("max")));*/

            DateFormat df = DateFormat.getDateTimeInstance();
            String updatedOn = df.format(new Date().getTime());
            updatedField.setText("Last update: " + updatedOn);

            drawIcon(details.getInt("id"));/*,
                    json.getJSONArray("list").getJSONObject(0).getInt("dt") * 1000,
                    (json.getJSONArray("list").getJSONObject(0).getInt("dt") + 21600) * 1000);*/

        } catch (Exception e) {
            Log.e("Nugget>Weather", "One or more fields missing in JSON data");
        }
    }

    private void refreshWeatherData(final String city) {
        new Thread() {
            public void run() {
                final JSONObject json = WeatherData.getJSON(getActivity(), city);
                if (json == null) {
                    handler.post(new Runnable() {
                        public void run() {
                            Toast.makeText(getActivity(),
                                    getActivity().getString(R.string.place_not_found),
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                } else {
                    handler.post(new Runnable() {
                        public void run() {
                            displayWeather(json);
                        }
                    });
                }
            }
        }.start();
    }

    public WeatherFragment() {
        handler = new Handler();
    }

    public void changeCity(String city){
        refreshWeatherData(city);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_weather, container, false);
        cityField = (TextView) rootView.findViewById(R.id.city_field);
        updatedField = (TextView) rootView.findViewById(R.id.updated_field);
        detailsField = (TextView) rootView.findViewById(R.id.details_field);
        currentTemperatureField = (TextView) rootView.findViewById(R.id.current_temperature_field);
        weatherIcon = (TextView) rootView.findViewById(R.id.weather_icon);

        weatherIcon.setTypeface(weatherFont);
        return rootView;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        weatherFont = Typeface.createFromAsset(getActivity().getAssets(), "fonts/weather.ttf");
        refreshWeatherData(new PickCity(getActivity()).getCity());
    }
}