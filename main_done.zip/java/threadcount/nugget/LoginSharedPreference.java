package threadcount.nugget;


import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import java.util.Date;

public class LoginSharedPreference {
    public static final String USERNAME = "name";
    public static final String PASSWORD = "pwd";
    public static final String NEXT_LOGIN = "next_log";
    public static final String NEXT_DB_UPDATE = "next_update" ;

    static SharedPreferences getSharedPreferences(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context);
    }

    public static void setLogin(Context context, String username, String password, long login) {
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putString(USERNAME, username);
        editor.putString(PASSWORD, password);
        editor.putLong(NEXT_LOGIN, login + 604800000l);
        editor.commit();
    }

    public static void setUpdate(Context context, long update) {
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putLong(NEXT_DB_UPDATE, update + 604800000l);
        editor.commit();
    }

    public static long getLogin(Context context) {
        return getSharedPreferences(context).getLong(NEXT_LOGIN, 0l);
    }

    public static long getUpdate(Context context) {
        return getSharedPreferences(context).getLong(NEXT_DB_UPDATE, 0l);
    }
    
    public static void clearData(Context context){
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.clear();
        editor.commit();
    }
}
