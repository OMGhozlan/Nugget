package threadcount.nugget;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class WeatherDataSource {

    // Database fields
    private SQLiteDatabase database;
    private WeatherDBHelper dbHelper;
    private String[] allColumns = WeatherDBHelper.WEATHER_INFO_COLUMNS;

    public WeatherDataSource(Context context) {
        this.dbHelper = new WeatherDBHelper(context);
    }

    public void open() throws SQLException {
        this.database = dbHelper.getWritableDatabase();
    }

    public void close() {
        this.dbHelper.close();
    }

    public WeatherItem createWeatherItem(int id, String date, double max, double min, String cond) {
        ContentValues values = new ContentValues();
        values.put(WeatherDBHelper.COLUMN_ID, id);
        values.put(WeatherDBHelper.COLUMN_WEATHER_MAIN, date);
        values.put(WeatherDBHelper.COLUMN_MAX_TEMP, max);
        values.put(WeatherDBHelper.COLUMN_MIN_TEMP, min);
        values.put(WeatherDBHelper.COLUMN_WEATHER_DESC, cond);
        /*long insertId = this.database.insert(WeatherDBHelper.TABLE_NAME_WEATHER_INFO, null,
                values);*/
        long insertId = this.database.replace(WeatherDBHelper.TABLE_NAME_WEATHER_INFO, null,
                values);
        Cursor cursor = this.database.query(WeatherDBHelper.TABLE_NAME_WEATHER_INFO,
                allColumns, WeatherDBHelper.COLUMN_ID + " = " + insertId, null,
                null, null, null);
        cursor.moveToFirst();
        WeatherItem newWeatherItem = cursorToWeatherItem(cursor);
        cursor.close();
        return newWeatherItem;
    }

    public void deleteWeatherItem(int id) {
        System.out.println("WeatherItem deleted with id: " + id);
        this.database.delete(WeatherDBHelper.TABLE_NAME_WEATHER_INFO, WeatherDBHelper.COLUMN_ID
                + " = " + id, null);
    }

    public ArrayList<WeatherItem> getAllWeatherItems() {
        ArrayList<WeatherItem> wi = new ArrayList<>();

        Cursor cursor = this.database.query(WeatherDBHelper.TABLE_NAME_WEATHER_INFO,
                allColumns, null, null, null, null, null);

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            WeatherItem w = cursorToWeatherItem(cursor);
            wi.add(w);
            cursor.moveToNext();
        }
        cursor.close();
        return wi;
    }

    private WeatherItem cursorToWeatherItem(Cursor cursor) {
        int i[] = {cursor.getColumnIndexOrThrow(WeatherDBHelper.COLUMN_ID),
                cursor.getColumnIndexOrThrow(WeatherDBHelper.COLUMN_WEATHER_MAIN)
                , cursor.getColumnIndexOrThrow(WeatherDBHelper.COLUMN_MAX_TEMP),
                cursor.getColumnIndexOrThrow(WeatherDBHelper.COLUMN_MIN_TEMP),
                cursor.getColumnIndexOrThrow(WeatherDBHelper.COLUMN_WEATHER_DESC)
        };
        /*WeatherDBHelper.COLUMN_MAX_TEMP
        WeatherDBHelper.COLUMN_MIN_TEMP
        WeatherDBHelper.COLUMN_WEATHER_DESC*/
        WeatherItem wi = new WeatherItem(cursor.getInt(i[0]),
                cursor.getString(i[1]), cursor.getDouble(i[2]), cursor.getDouble(i[3]),
                cursor.getString(i[4]));
        return wi;
    }
}

