package threadcount.nugget;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class WeatherDataSource {

    // Database fields
    private SQLiteDatabase database;
    private WeatherDBHelper dbHelper;
    private String[] allColumns = { WeatherDBHelper.COLUMN_ID,
            WeatherDBHelper.COLUMN_COMMENT };

    public WeatherDataSource(Context context) {
        dbHelper = new WeatherDBHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public WeatherItem createWeatherItem(String comment) {
        ContentValues values = new ContentValues();
        values.put(WeatherDBHelper.COLUMN_COMMENT, comment);
        long insertId = database.insert(WeatherDBHelper.TABLE_COMMENTS, null,
                values);
        Cursor cursor = database.query(WeatherDBHelper.TABLE_COMMENTS,
                allColumns, WeatherDBHelper.COLUMN_ID + " = " + insertId, null,
                null, null, null);
        cursor.moveToFirst();
        WeatherItem newWeatherItem = cursorToWeatherItem(cursor);
        cursor.close();
        return newWeatherItem;
    }

    public void deleteWeatherItem(WeatherItem wi) {
        long id = comment.getId();
        System.out.println("WeatherItem deleted with id: " + id);
        database.delete(WeatherDBHelper.TABLE_COMMENTS, WeatherDBHelper.COLUMN_ID
                + " = " + id, null);
    }

    public ArrayList<WeatherItem> getAllWeatherItems() {
        ArrayList<WeatherItem> comments = new ArrayList<>();

        Cursor cursor = database.query(WeatherDBHelper.TABLE_COMMENTS,
                allColumns, null, null, null, null, null);

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            WeatherItem comment = cursorToWeatherItem(cursor);
            comments.add(comment);
            cursor.moveToNext();
        }
        cursor.close();
        return wi;
    }

    private WeatherItem cursorToWeatherItem(Cursor cursor) {
        WeatherItem wi = new WeatherItem();
        wi.setId(cursor.getLong(0));
        wi.setWeatherItem(cursor.getString(1));
        return wi;
    }
}

